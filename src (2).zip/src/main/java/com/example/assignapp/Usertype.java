package com.example.assignapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Usertype extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Use the correct layout for this activity
        setContentView(R.layout.user_type);

        Button clientBtn = findViewById(R.id.button_client);
        Button counsellorBtn = findViewById(R.id.button_counsellor);

        // When CLIENT button is clicked
        clientBtn.setOnClickListener(v -> {

            Intent intent = new Intent(Usertype.this, logorsignin.class);

            // Send user type
            intent.putExtra("USER_TYPE", "client");

            startActivity(intent);
        });

        // When COUNSELLOR button is clicked
        counsellorBtn.setOnClickListener(v -> {

            Intent intent = new Intent(Usertype.this, logorsignin.class);

            // Send user type
            intent.putExtra("USER_TYPE", "counsellor");

            startActivity(intent);
        });
    }
}